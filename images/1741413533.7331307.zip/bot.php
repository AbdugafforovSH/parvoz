<?php
ob_start();

######### CREATE DB ###########
/*
CREATE TABLE `mirpay` (
  `id` int(100) NOT NULL,
  `pay_id` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE `mirpay`
  ADD PRIMARY KEY (`id`);
*/
######### END DB ##############


define("DB_SERVER","localhost"); 
define("DB_USERNAME","username"); 
define("DB_PASSWORD","password"); 
define("DB_NAME","username");

$connect = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
mysqli_set_charset($connect,"utf8mb4");

require("mirpay.php");
const API_KEY = "BOT_TOKEN";

$MirPay = new MirPay("kassa_id","api_key");
$MirPay->auth();


function get($h){
return file_get_contents($h);
}

function put($h,$r){
file_put_contents($h,$r);
}


function accl($d,$s,$j=false){
return bot('answerCallbackQuery',[
'callback_query_id'=>$d,
'text'=>$s,
'show_alert'=>$j
]);
}


function edit($id,$mid,$tx,$m=null){
return bot('editMessageText',[
'chat_id'=>$id,
'message_id'=>$mid,
'text'=>$tx,
'parse_mode'=>"HTML",
'reply_markup'=>$m,
]);
}

function inline($a=[]){
$d=json_encode([
"inline_keyboard"=>$a
]);
return $d;
}

function sms($id,$tx,$m=null){
return bot('sendMessage',[
'chat_id'=>$id,
'text'=>$tx,
'parse_mode'=>"HTML",
'reply_markup'=>$m,
]);
}

function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}

$update = json_decode(file_get_contents('php://input'));
$message = $update->message;
$text = $message->text;
$cid = $message->chat->id;
$mid = $message->message_id;

//callback _data methods.
$data = $update->callback_query->data;
$chat_id = $update->callback_query->message->from->id;
$message_id = $update->callback_query->message->message_id;
$qid = $update->callback_query->id;
if($message){
	mkdir("user");
	if(!get("user/$cid.balance")){
		put("user/$cid.balance","0");
		}
		}
		$step = get("user/".$cid."".$cid2.".step");
		if($text == "/start") {
			sms($cid,"💰 Hisobingiz ".get("user/$cid.balance")." so‘m",inline([
			[['text'=>"🔥 Pul kiritish",'callback_data'=>"addfund"]],
			]));
		
			}
			
			if($data == "addfunds") {
			sms($chat_id,"➡️ To‘lov miqdorini kiriting");
put("user/$cid2.step","addfunds");	
				}
				
				if($step == "addfunds" and is_numeric($text)){
					if($text >= 1000 and $text <= 10000000){
						
						$ok = $MirPay->create_checkout($text,("$text so‘m to‘lov"));
	$ok = json_decode($ok,1);
	if($ok['natija'] == "Muvaffaqiyatli"){
			$pay_url = $ok['payinfo']['redicet_url'];
			$pay_id = $ok['id'];
			sms($cid,"✅ To‘lov cheki muvaffaqiyatli yaratildi.

➡️ Quyidagi manzil orqali to'lov qiling va «✅ Tekshirish» tugmasini bosing.",inline([
		[['text'=>"➡️ To‘lov qilish",'web_app'=>['url'=>$pay_url]]],
		[['text'=>"✅ Tekshirish",'callback_data'=>"mirpay=".$pay_id]],
	]));
			}else{
				sms($cid,"⚠️ To'lov cheki yaratishda xatolik");
				}
						}else{
							sms($cid,"Min: 1000 so‘m, Max: 10,000,000 so‘m");
							}
							}
							
							if((stripos($data,"mirpay=")!==false)){
		$pay = explode("=",$data)[1];
		$ok = $mirPay->status_checkout($pay);
		$ok = json_decode($ok,1);
		$file = $connect->query("SELECT * FROM `mirpay` WHERE `pay_id` = '$pay'")->num_rows;
		if(!$file){
		$status = $ok['payinfo']['status'];
		$summa = $ok['payinfo']['summa'];
		
		if($status == "Muvaffaqiyatli"){
			
			sms($cid2,"✅ Hisobingiz $summa so‘m qabul qilindi.",null);
			$plus = get("user/{$cid2}.balance")+$summa;
			put("user/{$cid}.balance",$plus);
			$connect->query("INSERT INTO `mirpay`(`pay_id`) VALUES ('$pay');");
			}else{
				accl($qid,"⚠️ Ushbu to‘lov topilmadi yoki to‘lov qilinmagan.",1);
				}
		}else{
		accl($qid,"⚠️ Ushbu to‘lov xisobingizga o‘tkazilgan",1);
			}
		}